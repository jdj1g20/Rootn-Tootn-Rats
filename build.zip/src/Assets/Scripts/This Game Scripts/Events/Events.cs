using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Events
{
    // Variable names must match variables in the JSON.

    // List of all events
    public List<Event> events;
}

